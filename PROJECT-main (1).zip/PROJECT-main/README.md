# CODECHEF NOTIFIER
This is a browser extension removes the extra effort of checking the submission page to know the verdict of submissions made on codechef.
Whenever the submission of the problem on codechef is available it will notify the user through desktop notification, so that it will be easier for the programmers to work with the problems without repeatedly checking on the submission page. So that even if the server is down, once the verdict is predicted, it will be notified through desktop notification.
